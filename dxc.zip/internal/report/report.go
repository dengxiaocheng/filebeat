package report

import (
	"fmt"
	"io"
	"strings"

	"fbcap/internal/benchmark"
	"fbcap/internal/config"
)

func WriteValidation(w io.Writer, result benchmark.ValidationResult) {
	fmt.Fprintln(w, "validation: pass")
	fmt.Fprintf(w, "full_hash: %s\n", result.FullHash)
	fmt.Fprintf(w, "generate_hash: %s\n", result.GenerateHash)
	fmt.Fprintf(w, "samples_hash: %s\n", result.SamplesHash)
	if result.DimensionsHash != "" {
		fmt.Fprintf(w, "dimensions_hash: %s\n", result.DimensionsHash)
	}
	fmt.Fprintf(w, "sample_lines: %d\n", result.SampleLines)
	fmt.Fprintf(w, "parsed_sample_lines: %d\n", result.Plan.Profile.ParsedLines)
	fmt.Fprintf(w, "detected_processors: %s\n", strings.Join(result.DetectedProcessors, ","))
	if result.Plan.Template != "" {
		fmt.Fprintf(w, "template: %s\n", result.Plan.Template)
	}
	if result.Plan.TimeField != "" {
		fmt.Fprintf(w, "time_field: %s\n", result.Plan.TimeField)
	}
	if len(result.Plan.JSONFields) > 0 {
		fmt.Fprintf(w, "json_fields: %s\n", strings.Join(result.Plan.JSONFields, ","))
	}
	if len(result.Plan.Profile.DimensionFields) > 0 {
		fmt.Fprintf(w, "dimension_fields: %s\n", strings.Join(result.Plan.Profile.DimensionFields, ","))
	}
	for _, field := range result.Plan.Profile.Fields {
		rangePart := ""
		if field.Min != "" || field.Max != "" {
			rangePart = fmt.Sprintf(" range=%s..%s", field.Min, field.Max)
		}
		fmt.Fprintf(w, "field: %s kind=%s values=%s%s\n", field.Name, field.Kind, strings.Join(field.Values, "|"), rangePart)
	}
	for _, warning := range result.Warnings {
		fmt.Fprintf(w, "warning: %s\n", warning)
	}
}

func WriteBenchmark(w io.Writer, result benchmark.Result) {
	WriteValidation(w, result.Validation)
	if result.DryRun {
		fmt.Fprintln(w, "benchmark: skeleton dry-run only")
	}
	if len(result.Schedule) > 0 {
		fmt.Fprintln(w, "schedule:")
		for _, point := range result.Schedule {
			fmt.Fprintf(w, "  - qps: %d interval: %s duration: %s\n", point.QPS, point.EventInterval, point.Duration)
		}
	}
}

func Generate(w io.Writer, cfg config.ReportConfig) error {
	fmt.Fprintf(w, "report generation skeleton for run_dir=%s\n", cfg.RunDir)
	return nil
}
