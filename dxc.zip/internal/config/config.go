package config

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"flag"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

type RunConfig struct {
	Filebeat           string
	ProcessorsFull    string
	ProcessorsGenerate string
	Samples            string
	Dimensions         string
	RunDir             string

	QPS       []int
	Duration  time.Duration
	Warmup    time.Duration
	TimeField string
	StartTime string
	TimeStep  string
	Seed      int64
}

type ReportConfig struct {
	RunDir string
}

func ParseRunFlags(args []string) (RunConfig, error) {
	var rawQPS string
	cfg := RunConfig{}

	fs := flag.NewFlagSet("fbcap", flag.ContinueOnError)
	fs.StringVar(&cfg.Filebeat, "filebeat", "", "path to filebeat binary")
	fs.StringVar(&cfg.ProcessorsFull, "processors-full", "", "full production processors YAML")
	fs.StringVar(&cfg.ProcessorsGenerate, "processors-generate", "", "reduced processors YAML used for generation")
	fs.StringVar(&cfg.Samples, "samples", "", "sample log file")
	fs.StringVar(&cfg.Dimensions, "dimensions", "", "optional dimensions YAML")
	fs.StringVar(&cfg.RunDir, "run-dir", "", "run output directory")
	fs.StringVar(&rawQPS, "qps", "", "comma-separated qps list")
	fs.DurationVar(&cfg.Duration, "duration", 10*time.Minute, "benchmark duration")
	fs.DurationVar(&cfg.Warmup, "warmup", time.Minute, "warmup duration")
	fs.StringVar(&cfg.TimeField, "time-field", "", "event time field")
	fs.StringVar(&cfg.StartTime, "start-time", "", "event start time")
	fs.StringVar(&cfg.TimeStep, "time-step", "auto", "event time step or auto")
	fs.Int64Var(&cfg.Seed, "seed", 1, "deterministic generator seed")
	if err := fs.Parse(args); err != nil {
		return RunConfig{}, err
	}

	qps, err := parseQPS(rawQPS)
	if err != nil {
		return RunConfig{}, err
	}
	cfg.QPS = qps

	if cfg.ProcessorsFull == "" {
		return RunConfig{}, errors.New("--processors-full is required")
	}
	if cfg.ProcessorsGenerate == "" {
		return RunConfig{}, errors.New("--processors-generate is required")
	}
	if cfg.Samples == "" {
		return RunConfig{}, errors.New("--samples is required")
	}
	if cfg.Duration <= 0 {
		return RunConfig{}, errors.New("--duration must be positive")
	}
	if cfg.Warmup < 0 {
		return RunConfig{}, errors.New("--warmup must not be negative")
	}
	return cfg, nil
}

func ParseReportFlags(args []string) (ReportConfig, error) {
	cfg := ReportConfig{}
	fs := flag.NewFlagSet("fbcap report", flag.ContinueOnError)
	fs.StringVar(&cfg.RunDir, "run-dir", "", "run output directory")
	if err := fs.Parse(args); err != nil {
		return ReportConfig{}, err
	}
	if cfg.RunDir == "" {
		return ReportConfig{}, errors.New("--run-dir is required")
	}
	return cfg, nil
}

func ReadRequiredFile(path string) ([]byte, error) {
	if path == "" {
		return nil, errors.New("path is empty")
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	if len(data) == 0 {
		return nil, fmt.Errorf("%s is empty", path)
	}
	return data, nil
}

func SHA256Hex(data []byte) string {
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:])
}

func parseQPS(raw string) ([]int, error) {
	if strings.TrimSpace(raw) == "" {
		return nil, nil
	}
	parts := strings.Split(raw, ",")
	out := make([]int, 0, len(parts))
	for _, part := range parts {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		v, err := strconv.Atoi(part)
		if err != nil {
			return nil, fmt.Errorf("invalid qps %q: %w", part, err)
		}
		if v <= 0 {
			return nil, fmt.Errorf("qps must be positive: %d", v)
		}
		out = append(out, v)
	}
	return out, nil
}
