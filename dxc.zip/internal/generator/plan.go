package generator

import (
	"fbcap/internal/infer"
	"fbcap/internal/processors"
)

type Plan struct {
	Profile    infer.Profile
	Spec       processors.GenerateSpec
	Template   string
	TimeField  string
	JSONFields []string
}

func BuildPlan(profile infer.Profile, spec processors.GenerateSpec) Plan {
	plan := Plan{
		Profile:    profile,
		Spec:       spec,
		JSONFields: append([]string(nil), spec.JSONFields...),
	}
	if spec.Dissect != nil {
		plan.Template = spec.Dissect.Tokenizer
	}
	if spec.Timestamp != nil {
		plan.TimeField = spec.Timestamp.Field
	}
	return plan
}

func (p Plan) ReadyForPreview() bool {
	return p.Template != "" && p.Profile.ParsedLines > 0
}
