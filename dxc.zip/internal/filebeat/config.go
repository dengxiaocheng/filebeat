package filebeat

import (
	"fmt"
	"strings"

	"fbcap/internal/config"
)

func RenderConfig(cfg config.RunConfig, inputDir string, httpPort int, processorsYAML string) string {
	processorsBlock := strings.TrimSpace(processorsYAML)
	if processorsBlock == "" {
		processorsBlock = "processors: []"
	}
	return fmt.Sprintf(`filebeat.inputs:
  - type: filestream
    id: capacity
    paths:
      - %s/*.log

%s

output.discard: {}

http.enabled: true
http.host: 127.0.0.1
http.port: %d

path.data: ${path.data}
path.logs: ${path.logs}
logging.level: error
`, inputDir, processorsBlock, httpPort)
}
