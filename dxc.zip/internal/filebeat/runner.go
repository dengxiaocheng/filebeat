package filebeat

import "context"

type Runner struct {
	Binary string
}

type Process struct {
	PID int
}

func (r Runner) Start(ctx context.Context, configPath string) (*Process, error) {
	_ = ctx
	_ = configPath
	// TODO: start Filebeat with an isolated path.data/path.logs.
	return &Process{}, nil
}

func (p *Process) Stop(ctx context.Context) error {
	_ = ctx
	// TODO: terminate Filebeat and collect logs.
	return nil
}
