package writer

import "time"

type Accounting struct {
	GeneratedEvents uint64
	GeneratedLines  uint64
	GeneratedBytes  uint64
	WriterLagP95    time.Duration
}

type SchedulerConfig struct {
	QPS       int
	Duration  time.Duration
	TimeStep  string
	StartTime string
}

type SchedulePoint struct {
	QPS           int
	Duration      time.Duration
	EventInterval time.Duration
}

func BuildSchedule(qpsValues []int, duration time.Duration) []SchedulePoint {
	points := make([]SchedulePoint, 0, len(qpsValues))
	for _, qps := range qpsValues {
		if qps <= 0 {
			continue
		}
		points = append(points, SchedulePoint{
			QPS:           qps,
			Duration:      duration,
			EventInterval: time.Second / time.Duration(qps),
		})
	}
	return points
}
