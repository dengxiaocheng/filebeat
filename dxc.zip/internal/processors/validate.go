package processors

import (
	"fmt"
	"regexp"
	"sort"
	"strings"
)

type ValidationResult struct {
	Detected []string
	Warnings []string
}

type GenerateSpec struct {
	Validation ValidationResult
	Dissect    *DissectSpec
	JSONFields []string
	Timestamp  *TimestampSpec
}

type DissectSpec struct {
	Tokenizer    string
	Field        string
	TargetPrefix string
	Fields       []string
}

type TimestampSpec struct {
	Field   string
	Layouts []string
}

var (
	supportedGenerateProcessors = []string{
		"dissect",
		"decode_json_fields",
		"timestamp",
		"decode_csv_fields",
		"syslog",
		"decode_cef",
		"parse_aws_vpc_flow_log",
	}
	rejectedGenerateProcessors = []string{
		"drop_event",
		"script",
		"dns",
		"rate_limit",
	}
	warnGenerateProcessors = []string{
		"drop_fields",
		"include_fields",
		"add_fields",
		"add_tags",
		"add_labels",
		"add_host_metadata",
		"add_cloud_metadata",
		"add_kubernetes_metadata",
		"add_docker_metadata",
		"rename",
		"copy_fields",
		"replace",
		"convert",
	}
)

func ValidateGenerateConfig(data []byte) (ValidationResult, error) {
	text := string(data)
	for _, name := range rejectedGenerateProcessors {
		if hasProcessor(text, name) {
			return ValidationResult{}, fmt.Errorf("processors.generate.yml must not contain %q", name)
		}
	}

	var result ValidationResult
	for _, name := range supportedGenerateProcessors {
		if hasProcessor(text, name) {
			result.Detected = append(result.Detected, name)
		}
	}
	for _, name := range warnGenerateProcessors {
		if hasProcessor(text, name) {
			result.Warnings = append(result.Warnings, fmt.Sprintf("processor %q is usually not needed in processors.generate.yml", name))
		}
	}

	sort.Strings(result.Detected)
	if len(result.Detected) == 0 {
		return result, fmt.Errorf("processors.generate.yml has no supported generation processor")
	}
	return result, nil
}

func ParseGenerateConfig(data []byte) (GenerateSpec, error) {
	validation, err := ValidateGenerateConfig(data)
	if err != nil {
		return GenerateSpec{}, err
	}
	text := string(data)
	spec := GenerateSpec{Validation: validation}

	if hasProcessor(text, "dissect") {
		block := processorBlock(text, "dissect")
		tokenizer := firstYAMLScalar(block, "tokenizer")
		if tokenizer == "" {
			return GenerateSpec{}, fmt.Errorf("dissect processor requires tokenizer in processors.generate.yml")
		}
		spec.Dissect = &DissectSpec{
			Tokenizer:    tokenizer,
			Field:        defaultString(firstYAMLScalar(block, "field"), "message"),
			TargetPrefix: firstYAMLScalar(block, "target_prefix"),
			Fields:       DissectFieldNames(tokenizer),
		}
	}
	if hasProcessor(text, "decode_json_fields") {
		block := processorBlock(text, "decode_json_fields")
		spec.JSONFields = firstYAMLStringList(block, "fields")
		if len(spec.JSONFields) == 0 {
			return GenerateSpec{}, fmt.Errorf("decode_json_fields requires fields in processors.generate.yml")
		}
	}
	if hasProcessor(text, "timestamp") {
		block := processorBlock(text, "timestamp")
		field := firstYAMLScalar(block, "field")
		if field == "" {
			return GenerateSpec{}, fmt.Errorf("timestamp processor requires field in processors.generate.yml")
		}
		spec.Timestamp = &TimestampSpec{
			Field:   field,
			Layouts: firstYAMLStringList(block, "layouts"),
		}
	}
	return spec, nil
}

func DissectFieldNames(tokenizer string) []string {
	matches := regexp.MustCompile(`%\{([^}]*)\}`).FindAllStringSubmatch(tokenizer, -1)
	out := make([]string, 0, len(matches))
	seen := map[string]struct{}{}
	for _, match := range matches {
		name := normalizeDissectField(match[1])
		if name == "" {
			continue
		}
		if _, ok := seen[name]; ok {
			continue
		}
		seen[name] = struct{}{}
		out = append(out, name)
	}
	return out
}

func ParseDissectLine(tokenizer, line string) (map[string]string, bool) {
	parts := regexp.MustCompile(`%\{([^}]*)\}`).FindAllStringSubmatchIndex(tokenizer, -1)
	if len(parts) == 0 {
		return nil, tokenizer == line
	}

	values := map[string]string{}
	linePos := 0
	tokenPos := 0
	for i, part := range parts {
		literal := tokenizer[tokenPos:part[0]]
		if literal != "" {
			if linePos > len(line) {
				return nil, false
			}
			if !strings.HasPrefix(line[linePos:], literal) {
				return nil, false
			}
			linePos += len(literal)
		}

		nextLiteral := ""
		if i+1 < len(parts) {
			nextLiteral = tokenizer[part[1]:parts[i+1][0]]
		} else {
			nextLiteral = tokenizer[part[1]:]
		}

		rawName := tokenizer[part[2]:part[3]]
		name := normalizeDissectField(rawName)
		valueEnd := len(line)
		if nextLiteral != "" {
			if linePos > len(line) {
				return nil, false
			}
			next := strings.Index(line[linePos:], nextLiteral)
			if next < 0 {
				return nil, false
			}
			valueEnd = linePos + next
		}
		if name != "" {
			values[name] = line[linePos:valueEnd]
		}
		linePos = valueEnd
		tokenPos = part[1]
	}
	if suffix := tokenizer[tokenPos:]; suffix != "" {
		if linePos > len(line) {
			return nil, false
		}
		if !strings.HasPrefix(line[linePos:], suffix) {
			return nil, false
		}
		linePos += len(suffix)
	}
	return values, linePos == len(line)
}

func hasProcessor(text, name string) bool {
	pattern := fmt.Sprintf(`(?m)^\s*-\s*%s\s*:`, regexp.QuoteMeta(name))
	return regexp.MustCompile(pattern).FindStringIndex(text) != nil
}

func processorBlock(text, name string) string {
	lines := strings.Split(text, "\n")
	start := -1
	for i, line := range lines {
		if regexp.MustCompile(fmt.Sprintf(`^\s*-\s*%s\s*:`, regexp.QuoteMeta(name))).MatchString(line) {
			start = i
			break
		}
	}
	if start < 0 {
		return ""
	}
	end := len(lines)
	for i := start + 1; i < len(lines); i++ {
		if regexp.MustCompile(`^\s*-\s*[A-Za-z0-9_]+\s*:`).MatchString(lines[i]) {
			end = i
			break
		}
	}
	return strings.Join(lines[start:end], "\n")
}

func firstYAMLScalar(text, key string) string {
	pattern := fmt.Sprintf(`(?m)^\s*%s\s*:\s*(.+?)\s*$`, regexp.QuoteMeta(key))
	match := regexp.MustCompile(pattern).FindStringSubmatch(text)
	if len(match) == 0 {
		return ""
	}
	return trimYAMLScalar(match[1])
}

func firstYAMLStringList(text, key string) []string {
	inlinePattern := fmt.Sprintf(`(?m)^\s*%s\s*:\s*\[(.*?)\]\s*$`, regexp.QuoteMeta(key))
	if match := regexp.MustCompile(inlinePattern).FindStringSubmatch(text); len(match) > 0 {
		return splitInlineYAMLList(match[1])
	}
	blockPattern := fmt.Sprintf(`(?ms)^\s*%s\s*:\s*\n((?:\s*-\s*.+\n?)+)`, regexp.QuoteMeta(key))
	if match := regexp.MustCompile(blockPattern).FindStringSubmatch(text); len(match) > 0 {
		var out []string
		for _, line := range strings.Split(match[1], "\n") {
			line = strings.TrimSpace(line)
			if strings.HasPrefix(line, "-") {
				out = append(out, trimYAMLScalar(strings.TrimSpace(strings.TrimPrefix(line, "-"))))
			}
		}
		return out
	}
	return nil
}

func splitInlineYAMLList(raw string) []string {
	var out []string
	for _, item := range strings.Split(raw, ",") {
		item = trimYAMLScalar(strings.TrimSpace(item))
		if item != "" {
			out = append(out, item)
		}
	}
	return out
}

func trimYAMLScalar(raw string) string {
	raw = strings.TrimSpace(raw)
	raw = strings.Trim(raw, `"'`)
	return raw
}

func normalizeDissectField(raw string) string {
	raw = strings.TrimSpace(raw)
	raw = strings.TrimPrefix(raw, "?")
	raw = strings.TrimPrefix(raw, "*")
	raw = strings.TrimPrefix(raw, "+")
	raw = strings.TrimPrefix(raw, "&")
	for _, sep := range []string{"|", "/", "#", "->"} {
		if idx := strings.Index(raw, sep); idx >= 0 {
			raw = raw[:idx]
		}
	}
	return strings.TrimSpace(raw)
}

func defaultString(v, fallback string) string {
	if v == "" {
		return fallback
	}
	return v
}
