package benchmark

import (
	"context"
	"errors"

	"fbcap/internal/config"
	"fbcap/internal/writer"
)

type Runner struct {
	cfg config.RunConfig
}

type Result struct {
	Validation ValidationResult
	Schedule    []writer.SchedulePoint
	DryRun      bool
}

func NewRunner(cfg config.RunConfig) Runner {
	return Runner{cfg: cfg}
}

func (r Runner) Run(ctx context.Context) (Result, error) {
	if r.cfg.Filebeat == "" {
		return Result{}, errors.New("--filebeat is required for run")
	}
	if len(r.cfg.QPS) == 0 {
		return Result{}, errors.New("--qps is required for run")
	}
	validation, err := ValidateInputs(ctx, r.cfg)
	if err != nil {
		return Result{}, err
	}
	// TODO: execute preflight Filebeat validation, realtime writer, metrics sampling, and report persistence.
	return Result{
		Validation: validation,
		Schedule:   writer.BuildSchedule(r.cfg.QPS, r.cfg.Duration),
		DryRun:     true,
	}, nil
}
