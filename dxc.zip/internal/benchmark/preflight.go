package benchmark

import (
	"context"
	"fmt"
	"strings"

	"fbcap/internal/config"
	"fbcap/internal/generator"
	"fbcap/internal/infer"
	"fbcap/internal/processors"
)

type ValidationResult struct {
	FullHash      string
	GenerateHash  string
	SamplesHash   string
	DimensionsHash string
	SampleLines   int
	DetectedProcessors []string
	Warnings      []string
	Plan          generator.Plan
}

func ValidateInputs(ctx context.Context, cfg config.RunConfig) (ValidationResult, error) {
	_ = ctx

	full, err := config.ReadRequiredFile(cfg.ProcessorsFull)
	if err != nil {
		return ValidationResult{}, err
	}
	generate, err := config.ReadRequiredFile(cfg.ProcessorsGenerate)
	if err != nil {
		return ValidationResult{}, err
	}
	samples, err := config.ReadRequiredFile(cfg.Samples)
	if err != nil {
		return ValidationResult{}, err
	}
	var dimensions []byte
	var dimensionsHash string
	if cfg.Dimensions != "" {
		dimensions, err = config.ReadRequiredFile(cfg.Dimensions)
		if err != nil {
			return ValidationResult{}, err
		}
		dimensionsHash = config.SHA256Hex(dimensions)
	}

	spec, err := processors.ParseGenerateConfig(generate)
	if err != nil {
		return ValidationResult{}, err
	}
	profile := infer.FromSamples(samples, dimensions, spec)
	if profile.SampleLines == 0 {
		return ValidationResult{}, fmt.Errorf("samples.log has no non-empty log lines")
	}
	if spec.Dissect != nil && profile.ParsedLines != profile.SampleLines {
		return ValidationResult{}, fmt.Errorf("processors.generate.yml parsed %d/%d sample lines", profile.ParsedLines, profile.SampleLines)
	}
	if len(profile.Issues) > 0 {
		return ValidationResult{}, fmt.Errorf("sample validation failed: %s", strings.Join(profile.Issues, "; "))
	}
	plan := generator.BuildPlan(profile, spec)

	return ValidationResult{
		FullHash:           config.SHA256Hex(full),
		GenerateHash:       config.SHA256Hex(generate),
		SamplesHash:        config.SHA256Hex(samples),
		DimensionsHash:     dimensionsHash,
		SampleLines:        profile.SampleLines,
		DetectedProcessors: spec.Validation.Detected,
		Warnings:           spec.Validation.Warnings,
		Plan:               plan,
	}, nil
}
