package infer

import (
	"bytes"
	"encoding/json"
	"net"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"fbcap/internal/processors"
)

type Profile struct {
	SampleLines    int
	ParsedLines    int
	HasDimensions  bool
	DimensionFields []string
	Fields         []FieldProfile
	Issues         []string
}

type FieldProfile struct {
	Name   string
	Kind   string
	Values []string
	Min    string
	Max    string
}

func FromSamples(samples, dimensions []byte, spec processors.GenerateSpec) Profile {
	sampleLines := sampleLines(samples)
	fieldValues := map[string][]string{}
	parsedLines := 0
	var issues []string

	for lineNo, line := range splitNonEmptyLines(samples) {
		values := map[string]string{"message": line}
		ok := true
		if spec.Dissect != nil {
			values, ok = processors.ParseDissectLine(spec.Dissect.Tokenizer, line)
		}
		if !ok {
			continue
		}
		parsedLines++
		for k, v := range values {
			fieldValues[k] = append(fieldValues[k], v)
		}
		for _, jsonField := range spec.JSONFields {
			raw := values[jsonField]
			if raw == "" {
				continue
			}
			var decoded map[string]any
			if err := json.Unmarshal([]byte(raw), &decoded); err != nil {
				issues = append(issues, "line "+strconv.Itoa(lineNo+1)+": field "+jsonField+" is not valid JSON")
				continue
			}
			flattenJSON(jsonField, decoded, fieldValues)
		}
	}
	issues = append(issues, validateTimestampSamples(fieldValues, spec)...)

	fields := make([]FieldProfile, 0, len(fieldValues))
	for name, values := range fieldValues {
		fields = append(fields, summarizeField(name, values, spec))
	}
	sort.Slice(fields, func(i, j int) bool {
		return fields[i].Name < fields[j].Name
	})

	dimFields := extractDimensionFields(dimensions)
	sort.Strings(dimFields)

	return Profile{
		SampleLines:     sampleLines,
		ParsedLines:     parsedLines,
		HasDimensions:   len(bytes.TrimSpace(dimensions)) > 0,
		DimensionFields: dimFields,
		Fields:          fields,
		Issues:          issues,
	}
}

func sampleLines(samples []byte) int {
	lines := 0
	for _, line := range bytes.Split(samples, []byte{'\n'}) {
		if len(bytes.TrimSpace(line)) > 0 {
			lines++
		}
	}
	return lines
}

func splitNonEmptyLines(samples []byte) []string {
	var out []string
	for _, line := range bytes.Split(samples, []byte{'\n'}) {
		line = bytes.TrimSpace(line)
		if len(line) > 0 {
			out = append(out, string(line))
		}
	}
	return out
}

func flattenJSON(prefix string, value map[string]any, out map[string][]string) {
	for k, v := range value {
		name := prefix + "." + k
		switch typed := v.(type) {
		case map[string]any:
			flattenJSON(name, typed, out)
		case string:
			out[name] = append(out[name], typed)
		case float64:
			out[name] = append(out[name], strconv.FormatFloat(typed, 'f', -1, 64))
		case bool:
			out[name] = append(out[name], strconv.FormatBool(typed))
		default:
			data, err := json.Marshal(typed)
			if err == nil {
				out[name] = append(out[name], string(data))
			}
		}
	}
}

func summarizeField(name string, values []string, spec processors.GenerateSpec) FieldProfile {
	unique := uniqueStrings(values, 12)
	profile := FieldProfile{Name: name, Kind: inferKind(name, values, spec), Values: unique}
	if profile.Kind == "int" {
		min, max := intRange(values)
		profile.Min = min
		profile.Max = max
	}
	return profile
}

func inferKind(name string, values []string, spec processors.GenerateSpec) string {
	if spec.Timestamp != nil && name == spec.Timestamp.Field {
		return "timestamp"
	}
	allInt := true
	allIP := true
	allUUID := true
	for _, value := range values {
		if _, err := strconv.ParseInt(value, 10, 64); err != nil {
			allInt = false
		}
		if net.ParseIP(value) == nil {
			allIP = false
		}
		if !isUUID(value) {
			allUUID = false
		}
	}
	switch {
	case allInt:
		return "int"
	case allIP:
		return "ip"
	case allUUID:
		return "uuid"
	case len(uniqueStrings(values, 32)) <= 16:
		return "enum"
	default:
		return "string"
	}
}

func uniqueStrings(values []string, limit int) []string {
	seen := map[string]struct{}{}
	var out []string
	for _, value := range values {
		if _, ok := seen[value]; ok {
			continue
		}
		seen[value] = struct{}{}
		out = append(out, value)
		if len(out) >= limit {
			break
		}
	}
	sort.Strings(out)
	return out
}

func intRange(values []string) (string, string) {
	var min, max int64
	hasValue := false
	for _, value := range values {
		parsed, err := strconv.ParseInt(value, 10, 64)
		if err != nil {
			continue
		}
		if !hasValue || parsed < min {
			min = parsed
		}
		if !hasValue || parsed > max {
			max = parsed
		}
		hasValue = true
	}
	if !hasValue {
		return "", ""
	}
	return strconv.FormatInt(min, 10), strconv.FormatInt(max, 10)
}

func isUUID(value string) bool {
	return regexp.MustCompile(`(?i)^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$`).MatchString(value)
}

func extractDimensionFields(dimensions []byte) []string {
	matches := regexp.MustCompile(`(?m)^\s*field\s*:\s*(.+?)\s*$`).FindAllStringSubmatch(string(dimensions), -1)
	seen := map[string]struct{}{}
	var out []string
	for _, match := range matches {
		field := strings.Trim(strings.TrimSpace(match[1]), `"'`)
		if field == "" {
			continue
		}
		if _, ok := seen[field]; ok {
			continue
		}
		seen[field] = struct{}{}
		out = append(out, field)
	}
	return out
}

func validateTimestampSamples(fields map[string][]string, spec processors.GenerateSpec) []string {
	if spec.Timestamp == nil {
		return nil
	}
	if len(spec.Timestamp.Layouts) == 0 {
		return []string{"timestamp processor has no layouts"}
	}
	var issues []string
	for _, value := range fields[spec.Timestamp.Field] {
		if timestampMatchesAnyLayout(value, spec.Timestamp.Layouts) {
			continue
		}
		issues = append(issues, "timestamp field "+spec.Timestamp.Field+" does not match configured layouts: "+value)
	}
	return issues
}

func timestampMatchesAnyLayout(value string, layouts []string) bool {
	for _, layout := range layouts {
		if _, err := time.Parse(layout, value); err == nil {
			return true
		}
	}
	return false
}
