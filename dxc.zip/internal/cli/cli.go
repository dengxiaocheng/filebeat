package cli

import (
	"context"
	"fmt"
	"io"

	"fbcap/internal/benchmark"
	"fbcap/internal/config"
	"fbcap/internal/report"
)

func Main(args []string, stdout, stderr io.Writer) int {
	if len(args) == 0 {
		printUsage(stderr)
		return 2
	}

	ctx := context.Background()
	switch args[0] {
	case "validate":
		cfg, err := config.ParseRunFlags(args[1:])
		if err != nil {
			fmt.Fprintf(stderr, "validate: %v\n", err)
			return 2
		}
		result, err := benchmark.ValidateInputs(ctx, cfg)
		if err != nil {
			fmt.Fprintf(stderr, "validate: %v\n", err)
			return 1
		}
		report.WriteValidation(stdout, result)
		return 0
	case "run":
		cfg, err := config.ParseRunFlags(args[1:])
		if err != nil {
			fmt.Fprintf(stderr, "run: %v\n", err)
			return 2
		}
		result, err := benchmark.NewRunner(cfg).Run(ctx)
		if err != nil {
			fmt.Fprintf(stderr, "run: %v\n", err)
			return 1
		}
		report.WriteBenchmark(stdout, result)
		return 0
	case "report":
		cfg, err := config.ParseReportFlags(args[1:])
		if err != nil {
			fmt.Fprintf(stderr, "report: %v\n", err)
			return 2
		}
		if err := report.Generate(stdout, cfg); err != nil {
			fmt.Fprintf(stderr, "report: %v\n", err)
			return 1
		}
		return 0
	default:
		fmt.Fprintf(stderr, "unknown command %q\n", args[0])
		printUsage(stderr)
		return 2
	}
}

func printUsage(w io.Writer) {
	fmt.Fprintln(w, `usage:
  fbcap validate --processors-full processors.full.yml --processors-generate processors.generate.yml --samples samples.log
  fbcap run      --filebeat ./filebeat --processors-full processors.full.yml --processors-generate processors.generate.yml --samples samples.log --qps 1000,3000 --duration 10m
  fbcap report   --run-dir runs/example
`)
}
