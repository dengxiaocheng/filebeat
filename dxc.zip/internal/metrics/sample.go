package metrics

import "time"

type Sample struct {
	Time          time.Time
	CPUCores      float64
	RSSBytes      uint64
	DiskReadBytes uint64
	DiskWriteBytes uint64
	Threads       int
	OpenFiles     int
}

type Sampler interface {
	Sample(pid int) (Sample, error)
}
