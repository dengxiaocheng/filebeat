module fbcap

go 1.22
